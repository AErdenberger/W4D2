class Employee
    attr_reader :salary

    def initialize(name, title, salary, boss = nil)
        @name = name
        @title = title
        @salary = salary
        boss.employees << self if !boss.nil?
    end

    def bonus(multiplier)
        salary * multiplier
    end
end